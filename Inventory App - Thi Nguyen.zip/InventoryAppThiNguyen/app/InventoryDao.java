public class InventoryDao {
}
