package com.zybooks.inventoryapp_thinguyen.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import com.zybooks.inventoryapp_thinguyen.model.UserAccount;
import com.zybooks.inventoryapp_thinguyen.repo.UserAccountRepository;

public class UserAccountViewModel {
    private UserAccountRepository userAccountRepo;

    public UserAccountViewModel(@NonNull Application application) {
        userAccountRepo = UserAccountRepository.getInstance(application.getApplicationContext());
    }

    public long addUserAccount(UserAccount user) {
        return userAccountRepo.addUserAccount(user);
    }

    public UserAccount getUserAccount(String username, String password) {
        return userAccountRepo.getUserAccount(username, password);
    }

    public UserAccount getUserAccountByUsername(String username) {
        return userAccountRepo.getUserAccountByUsername(username);
    }
}
