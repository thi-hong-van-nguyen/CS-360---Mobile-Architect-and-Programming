package com.zybooks.inventoryapp_thinguyen;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.zybooks.inventoryapp_thinguyen.model.InventoryItem;
import com.zybooks.inventoryapp_thinguyen.viewmodel.InventoryItemListViewModel;
import java.util.List;
import java.util.Locale;
import android.Manifest;
import android.widget.Toast;
import android.telephony.SmsManager;
public class InventoryActivity extends AppCompatActivity {
    private InventoryAdapter mInventoryAdapter;
    private RecyclerView mRecyclerView;
    private InventoryItemListViewModel mInventoryListViewModel;
    private static final int EDIT_ITEM_REQUEST_CODE = 1;
    private ActivityResultLauncher<Intent> inventoryEditLauncher;
    private static final int PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        mInventoryListViewModel = new InventoryItemListViewModel(getApplication());
        mRecyclerView = findViewById(R.id.inventory_recycler_view);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Add event listener for add new item button
        findViewById(R.id.add_inventory_item_button).setOnClickListener(view -> addInventoryItemClick());

        // Define the layout for the item list
        RecyclerView.LayoutManager gridLayoutManager =
            new GridLayoutManager(getApplicationContext(), 1);
        mRecyclerView.setLayoutManager(gridLayoutManager);

        // Update UI with the list of inventory items
        updateUI(mInventoryListViewModel.getInventoryItems());

        // Create the activity result launcher
        inventoryEditLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    // Refresh the data and update the UI
                    updateUI(mInventoryListViewModel.getInventoryItems());
                }
            }
        );
    }

    private void updateUI(List<InventoryItem> inventoryItems) {
        mInventoryAdapter = new InventoryAdapter(inventoryItems);
        mRecyclerView.setAdapter(mInventoryAdapter);

//        sendLowInventorySMSNotification(inventoryItems);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.inventory_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // When user clicks on Logout
        if (item.getItemId() == R.id.logout) {
            logout();
            return true;
        } else if (item.getItemId() == R.id.notification_settings_menu_item) {
            // Handle the click action for "Turn on SMS notifications" item
            navigateToNotificationSettings();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void navigateToNotificationSettings() {
        // Navigate to Permission Request Activity
        Intent intent = new Intent(InventoryActivity.this, PermissionRequestActivity.class);
        startActivity(intent);
        finish();
    }

    private void addInventoryItemClick() {
        // Navigate to Edit Inventory Activity
        Intent intent = new Intent(InventoryActivity.this, InventoryEditActivity.class);
        inventoryEditLauncher.launch(intent);
    }

    private class InventoryHolder extends RecyclerView.ViewHolder
        {
        private InventoryItem mItem;
        private final TextView mItemNameTextView;
        private final TextView mItemQuantityTextView;
        private final TextView mItemUnitTextView;
        private final ImageView mMenuIcon;
        public InventoryHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.recycler_view_items, parent, false));
            mItemNameTextView = itemView.findViewById(R.id.itemNameTextView);
            mItemQuantityTextView = itemView.findViewById(R.id.itemQuantityTextView);
            mItemUnitTextView = itemView.findViewById(R.id.itemUnitTextView);
            mMenuIcon = itemView.findViewById(R.id.menuIcon);
        }
        public void bind(InventoryItem item, int position) {
            mItem = item;
            mItemNameTextView.setText(item.getName());
            formatQuantityTextView(item.getQuantity());
            mItemUnitTextView.setText(item.getUnit());

            mMenuIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showPopupMenu(view, item);
                }
            });
        }

            private void formatQuantityTextView(double quantity) {
                if (quantity == (int) quantity) {
                    mItemQuantityTextView.setText(String.format(Locale.getDefault(), "%.0f", quantity));
                } else {
                    mItemQuantityTextView.setText(String.valueOf(quantity));
                }
            }
        private void showPopupMenu(View view, InventoryItem item) {
        PopupMenu popupMenu = new PopupMenu(InventoryActivity.this, view);
        popupMenu.getMenuInflater().inflate(R.menu.inventory_item_menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
          @Override
          public boolean onMenuItemClick(MenuItem menuItem) {
              if (menuItem.getItemId() == R.id.edit_item) {
                  // Handle edit option
                  editInventoryItem(item);
                  return true;
              } else if (menuItem.getItemId() == R.id.remove_item) {
                  // Handle remove option
                  removeInventoryItem(item);
                  return true;
              }
              return false;
          }
        });
        popupMenu.show();
        }
    }
    private void editInventoryItem(InventoryItem item) {
        Intent intent = new Intent(InventoryActivity.this, InventoryEditActivity.class);
        intent.putExtra(InventoryEditActivity.EXTRA_ID, item.getId());
        inventoryEditLauncher.launch(intent);
    }

    private void removeInventoryItem(InventoryItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(InventoryActivity.this);
        builder.setTitle("Confirm Removal")
                .setMessage("Are you sure you want to remove this item?")
                .setPositiveButton("Remove", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // User clicked the "Remove" button, delete the item
                        mInventoryListViewModel.deleteInventoryItem(item);
                        // Refresh the data and update the UI
                        updateUI(mInventoryListViewModel.getInventoryItems());
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // User clicked the "Cancel" button, do nothing
                    }
                })
                .show();
    }

    private class InventoryAdapter extends RecyclerView.Adapter<InventoryHolder> {
        private final List<InventoryItem> mInventoryList;
        public InventoryAdapter(List<InventoryItem> inventories) {
            mInventoryList = inventories;
        }

        @NonNull
        @Override
        public InventoryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
            InventoryHolder holder = new InventoryHolder(layoutInflater, parent);
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Handle item click
                    // No need any action
                }
            });
            return holder;
        }

        @Override
        public void onBindViewHolder(InventoryHolder holder, int position){
            holder.bind(mInventoryList.get(position), position);
        }

        @Override
        public int getItemCount() {
            return mInventoryList.size();
        }
    }

    private void logout() {
        // Start the LoginActivity
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

}