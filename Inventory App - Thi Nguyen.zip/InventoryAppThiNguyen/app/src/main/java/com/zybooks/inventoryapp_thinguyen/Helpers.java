package com.zybooks.inventoryapp_thinguyen;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import com.zybooks.inventoryapp_thinguyen.model.InventoryItem;

public class Helpers {
    public static void sendSMS(Context context, InventoryItem mInventoryItem){
        // Check if SMS permission is granted. If yes, check inventory and send SMS if the inventory level is low
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            // Check if the item's quantity is lower than or equal to 10
            if (mInventoryItem.getQuantity() <= 10) {
                String phoneNumber = "4089123535"; // Replace with the recipient's phone number
                String message = "Low inventory for item: " + mInventoryItem.getName() + ". Quantity: " + mInventoryItem.getQuantity();

                try {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                    Toast.makeText(context, "SMS notification sent!", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(context, "Failed to send SMS notification.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}
