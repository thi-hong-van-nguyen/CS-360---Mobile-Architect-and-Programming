package com.zybooks.inventoryapp_thinguyen.repo;

import androidx.room.*;
import com.zybooks.inventoryapp_thinguyen.model.InventoryItem;
import java.util.List;

@Dao
public interface InventoryDao {
    @Query("SELECT * FROM InventoryItem WHERE id = :id")
    InventoryItem getInventoryItem(long id);

    @Query("SELECT * FROM InventoryItem WHERE name = :name")
    InventoryItem getInventoryItemByName(String name);

    @Query("SELECT * FROM InventoryItem ORDER BY name COLLATE NOCASE")
    List<InventoryItem> getInventoryItems();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long addInventoryItem(InventoryItem inventoryItem);

    @Update
    void updateInventoryItem(InventoryItem inventoryItem);

    @Delete
    void deleteInventoryItem(InventoryItem inventoryItem);
}
