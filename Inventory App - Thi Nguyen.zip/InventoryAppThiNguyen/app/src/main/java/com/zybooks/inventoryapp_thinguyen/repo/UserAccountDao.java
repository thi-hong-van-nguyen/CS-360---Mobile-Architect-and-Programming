package com.zybooks.inventoryapp_thinguyen.repo;

import androidx.room.*;
import com.zybooks.inventoryapp_thinguyen.model.UserAccount;
import java.util.List;

@Dao
public interface UserAccountDao {
    @Query("SELECT * FROM UserAccount WHERE username = :username AND password = :password")
    UserAccount getUserAccount(String username, String password);

    @Query("SELECT * FROM UserAccount WHERE username = :username")
    UserAccount getUserAccountByUsername(String username);

    @Query("SELECT * FROM UserAccount ORDER BY username COLLATE NOCASE")
    List<UserAccount> getUserAccounts();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long addUserAccount(UserAccount userAccount);
}
