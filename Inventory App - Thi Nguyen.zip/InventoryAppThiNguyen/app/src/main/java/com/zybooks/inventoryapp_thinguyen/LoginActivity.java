package com.zybooks.inventoryapp_thinguyen;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.zybooks.inventoryapp_thinguyen.model.UserAccount;
import com.zybooks.inventoryapp_thinguyen.viewmodel.InventoryItemListViewModel;
import com.zybooks.inventoryapp_thinguyen.viewmodel.UserAccountViewModel;

public class LoginActivity extends AppCompatActivity {
    private UserAccountViewModel mUserAccountViewModel;
    private EditText mUsernameEditText;
    private EditText mPasswordEditText;
    private Button mLoginSignupButton;
    private Button mLoginSwitchButton;
    private TextView mHaveAccountTextView;
    private TextView mLoginPageHeaderTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mUserAccountViewModel = new UserAccountViewModel(getApplication());

        // Initialize view
        mUsernameEditText = findViewById(R.id.usernameEditText);
        mPasswordEditText = findViewById(R.id.passwordEditText);
        mLoginSignupButton = findViewById(R.id.loginSignupButton);
        mLoginSwitchButton = findViewById(R.id.loginSwitchButton);
        mHaveAccountTextView = findViewById(R.id.haveAccountTextView);
        mLoginPageHeaderTextView = findViewById(R.id.loginPageHeaderTextView);
        mLoginSignupButton.setOnClickListener(view -> loginSignupClick());
        mLoginSwitchButton.setOnClickListener(view -> switchLoginSignupClick());

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }

    private void switchLoginSignupClick() {
        // If the loginSwitchButton text is currently signup
        // change loginSwitchButton and header text to "login"
        // change loginSignupButton and header text to "Sign up"
        // change haveAccountTextView text to "Already have an account?"
        if(mLoginSwitchButton.getText().toString().equals(getString(R.string.signup))){
            mLoginSwitchButton.setText(getString(R.string.login));
            mLoginSignupButton.setText(getString(R.string.signup));
            mLoginPageHeaderTextView.setText(getString(R.string.signup));
            mHaveAccountTextView.setText(getString(R.string.already_have_an_account));
        }
        // Else If the loginSwitchButton text is currently "login"
        // change loginSwitchButton text to "signup"
        // change loginSignupButton and header text to "Login"
        // change haveAccountTextView text to "Don't have an account?"
        else {
            mLoginSwitchButton.setText(getString(R.string.signup));
            mLoginSignupButton.setText(getString(R.string.login));
            mLoginPageHeaderTextView.setText(getString(R.string.login));
            mHaveAccountTextView.setText(getString(R.string.dont_have_an_account));
        }
    }

    private void loginSignupClick() {
        // Validate input
        // If there is no username or password, show error message
        if(mUsernameEditText.getText().toString().trim().isEmpty() || mPasswordEditText.getText().toString().trim().isEmpty()){
            Toast.makeText(this, "Username and password are required fields", Toast.LENGTH_SHORT).show();
        } else {
            String username = mUsernameEditText.getText().toString().trim();
            String password = mPasswordEditText.getText().toString().trim();
            // sign up
            if(mLoginSignupButton.getText() == getString(R.string.signup)){
                // check if the username already exists in the database
                UserAccount foundUserAccount = mUserAccountViewModel.getUserAccountByUsername(username);

                // User was not found
                if(foundUserAccount == null){
                    UserAccount newUserAccount = new UserAccount(username, password);
                    long insertedUserId = mUserAccountViewModel.addUserAccount(newUserAccount);
                    if(insertedUserId == -1){  // If inserting failed
                        Toast.makeText(this, "Something went wrong. Please try again", Toast.LENGTH_SHORT).show();
                        return;
                    } else {
                        Toast.makeText(this, "Your account has been successfully created!", Toast.LENGTH_SHORT).show();
                        // Start InventoryActivity
                        Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
                        startActivity(intent);
                        finish();
                    }
                // Found user
                } else {
                    Toast.makeText(this, "Username taken! Please choose another username.", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            // login
            else{
                // check username and password matches any user in DB
                UserAccount foundUser = mUserAccountViewModel.getUserAccount(username, password);
                if(foundUser == null){
                    Toast.makeText(this, "Invalid username or password!", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Start InventoryActivity
                Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
                startActivity(intent);
                finish();
            }
        }
    }
}