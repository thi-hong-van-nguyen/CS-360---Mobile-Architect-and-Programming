package com.zybooks.inventoryapp_thinguyen;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.zybooks.inventoryapp_thinguyen.model.InventoryItem;
import com.zybooks.inventoryapp_thinguyen.viewmodel.InventoryItemListViewModel;
import java.math.BigDecimal;
import java.util.List;

import android.Manifest;
public class InventoryEditActivity extends AppCompatActivity {

    public static final String EXTRA_ID = "com.zybooks.inventoryapp_thinguyen.id";
    private int maxCharacterCount = 50;
    private TextView characterCountTextView;
    private InventoryItemListViewModel mInventoryListViewModel;
    private long id;

    private EditText itemNameEditText;
    private EditText quantityEditText;
    private Button saveChangesButton;
    private TextView headerTextView;
    private Toolbar toolbar;
    private Spinner unitSpinner;
    private ImageView minusIcon;
    private ImageView plusIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_edit);

        itemNameEditText = findViewById(R.id.editTextItemName);
        quantityEditText = findViewById(R.id.editTextQuantity);
        saveChangesButton = findViewById(R.id.saveChangesButton);
        headerTextView = findViewById(R.id.edit_inventory_item_header_textview);
        toolbar = findViewById(R.id.edit_view_toolbar);
        unitSpinner = findViewById(R.id.unitSpinner);
        minusIcon = findViewById(R.id.minusIcon);
        plusIcon = findViewById(R.id.plusIcon);
        characterCountTextView = findViewById(R.id.characterCountTextView);

        // Enable the home button (back button) with the up navigation indicator
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Add dropdown items to the unitSpinner
        ArrayAdapter<CharSequence> unitAdapter = ArrayAdapter.createFromResource(this, R.array.units_array, android.R.layout.simple_spinner_item);
        unitAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        unitSpinner.setAdapter(unitAdapter);

        // Create a listener for Save Changes button
        saveChangesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveChangesButtonClick();
            }
        });

        // Create a listener for MinusIcon
        minusIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                subtractOneFromQuantity();
            }
        });

        // Create a listener for PlusIcon
        plusIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addOneToQuantity();
            }
        });

        // Retrieve the inventory item ID from the intent
        Intent intent = getIntent();
        long itemId = intent.getLongExtra(EXTRA_ID, -1);
        id = itemId;
        mInventoryListViewModel = new InventoryItemListViewModel(getApplication());

        // If itemId = -1, change the View to Add New Inventory Item
        if(itemId == -1){
            // change title and button text
            headerTextView.setText(R.string.add_inventory_item);
            saveChangesButton.setText(R.string.save_new_item);
            quantityEditText.setText("0");
        } else {
            // Retrieve the inventory item from the database using the item ID
            InventoryItem inventoryItem = mInventoryListViewModel.getInventoryItemById(itemId);
            if (inventoryItem != null) {
                // Set the values of the views using the retrieved inventory item data
                itemNameEditText.setText(inventoryItem.getName());
                quantityEditText.setText(String.valueOf(inventoryItem.getQuantity()));

                // Set the selection of the unitSpinner based on the inventory item's unit
                unitAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                unitSpinner.setAdapter(unitAdapter);
                if (inventoryItem.getUnit() != null) {
                    int unitIndex = unitAdapter.getPosition(inventoryItem.getUnit());
                    unitSpinner.setSelection(unitIndex);
                }

                // update the item name count
                int currentCharacterCount = inventoryItem.getName().length();
                updateCount(currentCharacterCount);
            }
        }

        // Add a text change listener to the itemNameEditText
        itemNameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Not used
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Update the character count dynamically
                int currentCharacterCount = s.length();
                updateCount(currentCharacterCount);
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Not used
            }
        });
    }

    private void saveChangesButtonClick() {
        String itemName = itemNameEditText.getText().toString().trim();
        double quantity = Double.parseDouble(quantityEditText.getText().toString());
        String unit = unitSpinner.getSelectedItem().toString();

        // Validate the input name - not null
        if (itemName.isEmpty()) {
            Toast.makeText(this, "Item name is required!", Toast.LENGTH_SHORT).show();
            return;
        }
        // input should not exceed 50char
        if(itemName.length() > 50){
            Toast.makeText(this, "Item name is 50 characters max!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create the new InventoryItem object
        InventoryItem item = new InventoryItem(itemName);
        item.setQuantity(quantity);
        item.setUnit(unit);

        if (id == -1) {  // Add new item
            // Check if the item name is taken. Item name should be unique
            InventoryItem foundItem = mInventoryListViewModel.getInventoryItemByName(itemName);
            // If not found, new item is valid. Add new item to the DB
            if(foundItem == null) {
                mInventoryListViewModel.addInventoryItem(item);
                Toast.makeText(this, "New item has been successfully added.", Toast.LENGTH_SHORT).show();
                notifyLowInventory(item);
            } else {
                // Else, if the item is taken, show error
                Toast.makeText(this, "Item name is taken. Please choose a different name.", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        else {  // Update item
            // Check if the name is unique
            InventoryItem foundItem = mInventoryListViewModel.getInventoryItemByName(itemName);
            if(foundItem != null && id != foundItem.getId()) {
                Toast.makeText(this, "Name is taken. Please choose a different name.", Toast.LENGTH_SHORT).show();
                return;
            } else {
                // Update the InventoryItem in the ViewModel
                item.setId(id);
                mInventoryListViewModel.updateInventoryItem(item);
                Toast.makeText(this, "Item updated successfully", Toast.LENGTH_SHORT).show();
                notifyLowInventory(item);
            }

        }

        // Pass the updated item ID back to InventoryActivity
        Intent resultIntent = new Intent();
        resultIntent.putExtra(InventoryEditActivity.EXTRA_ID, item.getId());
        setResult(RESULT_OK, resultIntent);

        // Finish the activity and return to InventoryActivity
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Handle the back button click (up navigation)
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void subtractOneFromQuantity() {
        String quantityString = quantityEditText.getText().toString();
        BigDecimal quantity = new BigDecimal(quantityString);
        BigDecimal one = new BigDecimal("1");

        if (quantity.compareTo(one) >= 0) { // Add condition to make sure the quantity is enough to subtract
            quantity = quantity.subtract(one);
            quantityEditText.setText(quantity.stripTrailingZeros().toPlainString());
        }
    }

    private void addOneToQuantity() {
        String quantityString = quantityEditText.getText().toString();
        double quantity = Double.parseDouble(quantityString);
        quantity += 1;
        quantityEditText.setText(String.valueOf(quantity));
    }

    private void updateCount(int count){
        String characterCountText = "Max char: " + count + "/" + maxCharacterCount;
        characterCountTextView.setText(characterCountText);
    }

    private void notifyLowInventory(InventoryItem inventoryItem){
        Helpers.sendSMS(this, inventoryItem);
    }
}