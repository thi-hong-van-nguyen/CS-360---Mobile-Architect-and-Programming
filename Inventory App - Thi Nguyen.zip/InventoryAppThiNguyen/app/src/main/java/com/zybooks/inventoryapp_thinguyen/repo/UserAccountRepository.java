package com.zybooks.inventoryapp_thinguyen.repo;

import android.content.Context;
import androidx.room.Room;
import com.zybooks.inventoryapp_thinguyen.model.UserAccount;

public class UserAccountRepository {
    private static UserAccountRepository mUserAccountRepo;
    private final UserAccountDao mUserAccountDao;

    public static UserAccountRepository getInstance(Context context) {
        if (mUserAccountRepo == null) {
            mUserAccountRepo = new UserAccountRepository(context);
        }
        return mUserAccountRepo;
    }

    private UserAccountRepository(Context context) {
        AppDatabase database = Room.databaseBuilder(context, AppDatabase.class, "inventoryApp.db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        mUserAccountDao = database.userAccountDao();

        if (mUserAccountDao.getUserAccounts().isEmpty()) {
            addStarterData();
        }
    }

    private void addStarterData() {
        // Add a user account
        UserAccount user = new UserAccount("cs360", "1234");
        mUserAccountDao.addUserAccount(user);
    }

    public long addUserAccount(UserAccount user) {
        return mUserAccountDao.addUserAccount(user);
    }

    public UserAccount getUserAccount(String username, String password) {
        return mUserAccountDao.getUserAccount(username, password);
    }

    public UserAccount getUserAccountByUsername(String username) {
        return mUserAccountDao.getUserAccountByUsername(username);
    }
}
