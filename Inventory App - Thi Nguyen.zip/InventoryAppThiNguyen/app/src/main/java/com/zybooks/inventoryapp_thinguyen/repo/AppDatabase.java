package com.zybooks.inventoryapp_thinguyen.repo;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import com.zybooks.inventoryapp_thinguyen.model.InventoryItem;
import com.zybooks.inventoryapp_thinguyen.model.UserAccount;

@Database(entities = {InventoryItem.class, UserAccount.class}, version = 3)
public abstract class AppDatabase extends RoomDatabase {
    public abstract  UserAccountDao userAccountDao();
    public abstract InventoryDao inventoryDao();
}

