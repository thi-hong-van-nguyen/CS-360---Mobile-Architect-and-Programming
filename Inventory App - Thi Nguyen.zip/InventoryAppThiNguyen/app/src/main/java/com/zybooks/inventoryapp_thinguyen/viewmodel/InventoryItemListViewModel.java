package com.zybooks.inventoryapp_thinguyen.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import com.zybooks.inventoryapp_thinguyen.model.InventoryItem;
import com.zybooks.inventoryapp_thinguyen.repo.InventoryRepository;
import java.util.List;

public class InventoryItemListViewModel {
    private InventoryRepository inventoryRepo;

    public InventoryItemListViewModel(@NonNull Application application) {
        inventoryRepo = InventoryRepository.getInstance(application.getApplicationContext());
    }

    public List<InventoryItem> getInventoryItems() {
        return inventoryRepo.getInventoryItems();
    }

    public void addInventoryItem(InventoryItem item) {
        inventoryRepo.addInventoryItem(item);
    }

    public InventoryItem getInventoryItemById(long itemId) {
        return inventoryRepo.getInventoryItem(itemId);
    }

    public InventoryItem getInventoryItemByName(String name) {
        return inventoryRepo.getInventoryItemByName(name);
    }

    public void updateInventoryItem(InventoryItem item) {
        inventoryRepo.updateInventoryItem(item);
    }

    public void deleteInventoryItem(InventoryItem item) {
        inventoryRepo.deleteInventoryItem(item);
    }
}
