package com.zybooks.inventoryapp_thinguyen.repo;

import android.content.Context;
import androidx.room.Room;

import com.zybooks.inventoryapp_thinguyen.R;
import com.zybooks.inventoryapp_thinguyen.model.InventoryItem;
import java.util.List;

public class InventoryRepository {
    private static InventoryRepository mInventoryRepo;
    private final InventoryDao mInventoryDao;
    private Context mContext; // Add a member variable to store the context

    public static InventoryRepository getInstance(Context context) {
        if (mInventoryRepo == null) {
            mInventoryRepo = new InventoryRepository(context);
        }
        return mInventoryRepo;
    }

    private InventoryRepository(Context context) {
        mContext = context; // Store the context in the member variable

        AppDatabase database = Room.databaseBuilder(context, AppDatabase.class, "inventoryApp.db")
                .allowMainThreadQueries()
                .build();

        mInventoryDao = database.inventoryDao();

        if (mInventoryDao.getInventoryItems().isEmpty()) {
            addStarterData();
        }
    }

    private void addStarterData() {
        // Add a few Inventory Items
        InventoryItem item = new InventoryItem("Hello World T-shirt");
        item.setQuantity(20);
        item.setUnit(mContext.getString(R.string.pcs));
        mInventoryDao.addInventoryItem(item);

        item = new InventoryItem("Airpod case");
        item.setQuantity(12);
        item.setUnit(mContext.getString(R.string.pcs));
        mInventoryDao.addInventoryItem(item);

        item = new InventoryItem("Nike shoes");
        item.setQuantity(40);
        item.setUnit(mContext.getString(R.string.pairs));
        mInventoryDao.addInventoryItem(item);

        item = new InventoryItem("Plant Soil");
        item.setQuantity(101.25);
        item.setUnit(mContext.getString(R.string.kg));
        mInventoryDao.addInventoryItem(item);
    }

    public void addInventoryItem(InventoryItem item) {
        mInventoryDao.addInventoryItem(item);
    }

    public InventoryItem getInventoryItem(long inventoryId) {
        return mInventoryDao.getInventoryItem(inventoryId);
    }

    public InventoryItem getInventoryItemByName(String name) {
        return mInventoryDao.getInventoryItemByName(name);
    }

    public List<InventoryItem> getInventoryItems() {
    return mInventoryDao.getInventoryItems();
}

    public void updateInventoryItem(InventoryItem item) {
        mInventoryDao.updateInventoryItem(item);
    }

    public void deleteInventoryItem(InventoryItem item) {
        mInventoryDao.deleteInventoryItem(item);
    }
}
