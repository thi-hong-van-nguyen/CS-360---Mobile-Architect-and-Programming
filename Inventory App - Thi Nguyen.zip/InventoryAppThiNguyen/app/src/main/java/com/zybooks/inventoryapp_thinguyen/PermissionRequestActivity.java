package com.zybooks.inventoryapp_thinguyen;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;

import com.zybooks.inventoryapp_thinguyen.model.InventoryItem;
import com.zybooks.inventoryapp_thinguyen.viewmodel.InventoryItemListViewModel;

import java.util.List;
import java.util.Objects;

public class PermissionRequestActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission_request);

        Button permissionButton = findViewById(R.id.permissionButton);
        TextView permissionDescriptionTextView = findViewById(R.id.permissionDescriptionTextView);
        Toolbar toolbar = findViewById(R.id.permission_request_view_toolbar);

        // Enable the home button (back button) with the up navigation indicator
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        // If the permission is already granted, show "Permission already granted text" and hide the button
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            permissionDescriptionTextView.setText(getString(R.string.permission_already_granted));
            permissionButton.setVisibility(View.GONE); // Hide the button
        }

        permissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSendSMSPermission();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Handle the back button click (up navigation)
        if (item.getItemId() == android.R.id.home) {
            goBackToInventoryActivity();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void requestSendSMSPermission() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.SEND_SMS},
                PERMISSION_REQUEST_CODE);
    }

    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, return to main activity with granted result
                Toast.makeText(this, "SMS notifications turned on.", Toast.LENGTH_SHORT).show();

                // After permission is granted, check the inventory to see if there is any item inventory lower than 10 and send SMS to notify
                InventoryItemListViewModel vm = new InventoryItemListViewModel(getApplication());
                List<InventoryItem> mInventoryItems = vm.getInventoryItems();
                for(InventoryItem inventoryItem : mInventoryItems){
                    Helpers.sendSMS(this, inventoryItem);
                }

                goBackToInventoryActivity();
            }
        }
    }

    private void goBackToInventoryActivity(){
        Intent intent = new Intent(PermissionRequestActivity.this, InventoryActivity.class);
        startActivity(intent);
        finish();
    }
}